Syndy Emade Foundation press kit

Fact sheet (PDF) and the official logo (PNG).
- logo.png: transparent background, for white or light backgrounds
- logo-original.png: as supplied, on white
The purple lettering is not legible on dark backgrounds: place the logo on white.
Please do not recolour or distort the logo.

Media enquiries: info@syndyemadefoundation.org
