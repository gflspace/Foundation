Syndy Emade Foundation press kit

fact sheet (PDF), logo mark and lockups (SVG + PNG).
Use the on-dark lockup on navy or photographic backgrounds; on-light on white.
Please do not recolour or distort the logo.

Media enquiries: hello@syndyemadefoundation.org
