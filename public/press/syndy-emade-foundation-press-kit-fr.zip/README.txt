Dossier de presse de la Fondation Syndy Emade

Fiche d’information (PDF), logo et déclinaisons (SVG + PNG).
Utilisez la version claire sur fond bleu nuit ou photo, et la version foncée sur fond blanc.
Merci de ne pas modifier les couleurs ni les proportions du logo.

Contact presse : hello@syndyemadefoundation.org
