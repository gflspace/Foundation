Dossier de presse de la Fondation Syndy Emade

Fiche d’information (PDF) et logo officiel (PNG).
- logo.png : fond transparent, pour fonds blancs ou clairs
- logo-original.png : version fournie, sur fond blanc
Le lettrage violet n’est pas lisible sur fond sombre : placez le logo sur fond blanc.
Merci de ne pas modifier les couleurs ni les proportions du logo.

Contact presse : info@syndyemadefoundation.org
